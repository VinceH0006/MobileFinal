//
//  ViewController.swift
//  Juicy
//
//  Created by Will Morphy on 16/11/18.
//  Copyright © 2018 Will Morphy. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

