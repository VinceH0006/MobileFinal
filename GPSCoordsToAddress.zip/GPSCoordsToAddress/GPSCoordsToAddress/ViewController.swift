//
//  ViewController.swift
//  GPSCoordsToAddress
//
//  Created by Vincent Hochstein on 12/10/18.
//  Copyright © 2018 Vincent Hochstein. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController, MKMapViewDelegate {

    @IBOutlet weak var MapView: MKMapView!
    
    var location = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        MapView.showsUserLocation = true
        MapView.delegate = self
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func ButtonAddress(_ sender: Any) {
        
        let userLocation = MapView.userLocation
        let region = MKCoordinateRegion.init(center: ((userLocation.location?.coordinate)!), latitudinalMeters: 1000, longitudinalMeters: 1000)
        
        MapView.setRegion(region, animated: true)
        
        var longitude :CLLocationDegrees = (self.location.location?.coordinate.longitude)!
        var latitude :CLLocationDegrees = (self.location.location?.coordinate.latitude)!
        
        var location = CLLocation(latitude: latitude, longitude: longitude)
        
        CLGeocoder().reverseGeocodeLocation(location, completionHandler: {(placemarks, error) -> Void in
            
            if error != nil {
                
                print ("Failed")
                return
            }
            
            if (placemarks?.count)! > 0 {
                
                let pm = placemarks?[0]
                
                let address = (pm?.subThoroughfare)! + " " + (pm?.thoroughfare)! + " " + (pm?.locality)! + ", " + (pm?.administrativeArea)! + " " + (pm?.postalCode)! + " " + (pm?.isoCountryCode)!
                
                print (address)
            }
            
            else {
                print ("An error has occured.")
            }
        })
        
    }
    
    func mapView(_ mapView: MKMapView, didUpdate userLocation: MKUserLocation) {
        MapView.centerCoordinate = userLocation.location!.coordinate
        
    }
    
    @IBOutlet weak var TextOut: UITextField!
    
    
}

